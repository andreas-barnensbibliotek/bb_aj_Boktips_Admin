module.exports = {
    entry: "./_dev/devjs/app.js",
    mode: 'development',
    output: {
        path: __dirname,
        filename: "../_dev/jsbundle/aj_bb_boktipsadmin_KrypinbundleWebpack.1.0.js"
    }
};
