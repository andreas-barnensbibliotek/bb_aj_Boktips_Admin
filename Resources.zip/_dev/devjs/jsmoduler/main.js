

module.exports = {
    testar: function (msg) {
        
        alert(msg);
    }
}
