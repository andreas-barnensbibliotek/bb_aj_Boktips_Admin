var dt = require("./jsmoduler/dataTablehandler/DataTableMainHandler.js");
var $ = require("jquery");
   
$(function () {

    let init = function () {
       
        dt.init();
    }

    init();      
   
    
});
